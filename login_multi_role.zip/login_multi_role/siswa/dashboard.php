<?php
session_start();
require_once '../config/koneksi.php';

// Cek otorisasi: pastikan sudah login dan rolenya siswa
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'siswa') {
    header("Location: ../auth/login.php");
    exit;
}

$id_user = $_SESSION['id'];
$query = mysqli_query($conn, "SELECT nama, username, email, role FROM users WHERE id='$id_user'");
$user_data = mysqli_fetch_assoc($query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Siswa</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f7f6; color: #333; padding: 40px; }
        .container { max-width: 600px; margin: 0 auto; }
        h1 { color: #2c3e50; margin-bottom: 20px; font-size: 24px; }
        .card { background: #ffffff; padding: 25px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05); }
        .card h3 { margin-bottom: 15px; color: #34495e; border-bottom: 2px solid #f1f1f1; padding-bottom: 8px; }
        .card p { margin: 12px 0; line-height: 1.6; }
        .role-badge { background: #3498db; color: white; padding: 3px 10px; border-radius: 4px; font-size: 12px; text-transform: uppercase; font-weight: bold; }
        .btn-logout { display: inline-block; margin-top: 20px; background-color: #7f8c8d; color: white; padding: 10px 20px; border-radius: 6px; text-decoration: none; font-weight: 600; transition: background 0.2s; }
        .btn-logout:hover { background-color: #717d7e; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Selamat Datang, <?php echo htmlspecialchars($user_data['nama']); ?>!</h1>
        
        <div class="card">
            <h3>Profil Siswa</h3>
            <p><strong>Nama Lengkap:</strong> <?php echo htmlspecialchars($user_data['nama']); ?></p>
            <p><strong>Username:</strong> <?php echo htmlspecialchars($user_data['username']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($user_data['email']); ?></p>
            <p><strong>Role:</strong> <span class="role-badge"><?php echo htmlspecialchars($user_data['role']); ?></span></p>
        </div>
        
        <a href="../auth/logout.php" class="btn-logout">Logout</a>
    </div>
</body>
</html>