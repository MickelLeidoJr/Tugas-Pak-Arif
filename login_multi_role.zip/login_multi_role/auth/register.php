<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register User - Sistem Informasi Sekolah</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background-color: #f4f7f6; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            min-height: 100vh; 
            padding: 20px; 
        }
        .register-card { 
            background: #ffffff; 
            padding: 30px; 
            border-radius: 12px; 
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05); 
            width: 100%; 
            max-width: 450px; 
        }
        h2 { 
            color: #2c3e50; 
            margin-bottom: 20px; 
            text-align: center; 
        }
        label { 
            display: block; 
            margin-bottom: 5px; 
            color: #34495e; 
            font-weight: 600; 
            font-size: 13px; 
        }
        input, select { 
            width: 100%; 
            padding: 9px 12px; 
            margin-bottom: 12px; 
            border: 1px solid #ccc; 
            border-radius: 6px; 
            font-size: 14px; 
        }
        input:focus, select:focus { 
            border-color: #3498db; 
            outline: none; 
        }
        button { 
            width: 100%; 
            background-color: #2ecc71; 
            color: white; 
            padding: 10px; 
            border: none; 
            border-radius: 6px; 
            font-size: 16px; 
            font-weight: 600; 
            cursor: pointer; 
            transition: background 0.2s; 
            margin-top: 5px;
        }
        button:hover { 
            background-color: #27ae60; 
        }
        p { 
            text-align: center; 
            margin-top: 15px; 
            font-size: 14px; 
            color: #666; 
        }
        p a { 
            color: #3498db; 
            text-decoration: none; 
            font-weight: 600; 
        }
        p a:hover { 
            text-decoration: underline; 
        }
    </style>
</head>
<body>
    <div class="register-card">
        <h2>Form Pendaftaran</h2>
        <form action="proses_register.php" method="POST">
            <label>Nama Lengkap</label>
            <input type="text" name="nama" placeholder="Nama lengkap Anda" required>
            
            <label>Username</label>
            <input type="text" name="username" placeholder="Buat username" required>
            
            <label>Email</label>
            <input type="email" name="email" placeholder="Alamat email aktif" required>
            
            <label>Password</label>
            <input type="password" name="password" placeholder="Password minimal" required>
            
            <label>Konfirmasi Password</label>
            <input type="password" name="konfirmasi_password" placeholder="Ulangi password" required>
            
            <label>Daftar Sebagai</label>
            <select name="role" required>
                <option value="siswa">Siswa</option>
                <option value="guru">Guru</option>
                <option value="admin">Admin</option>
            </select>
            
            <button type="submit">Daftar Sekarang</button>
        </form>
        <p>Sudah punya akun? <a href="login.php">Login di sini</a></p>
    </div>
</body>
</html>