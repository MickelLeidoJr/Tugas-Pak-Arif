<?php
session_start();
require_once '../config/koneksi.php';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = mysqli_query($conn, "SELECT * FROM users WHERE username='$username'");

    if (mysqli_num_rows($query) === 1) {
        $row = mysqli_fetch_assoc($query);

        if (password_verify($password, $row['password'])) {
            $_SESSION['id']       = $row['id'];
            $_SESSION['nama']     = $row['nama'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['role']     = $row['role'];

            if ($row['role'] == 'admin') {
                header("Location: ../admin/dashboard.php");
            } elseif ($row['role'] == 'guru') {
                header("Location: ../guru/dashboard.php");
            } else {
                header("Location: ../siswa/dashboard.php");
            }
            exit;
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Username tidak terdaftar!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Informasi Sekolah</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background-color: #f4f7f6; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            height: 100vh; 
        }
        .login-card { 
            background: #ffffff; 
            padding: 30px; 
            border-radius: 12px; 
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05); 
            width: 100%; 
            max-width: 400px; 
        }
        h2 { 
            color: #2c3e50; 
            margin-bottom: 20px; 
            text-align: center; 
        }
        .error-msg { 
            background: #ffdddd; 
            color: #d8000c; 
            padding: 10px; 
            border-radius: 6px; 
            margin-bottom: 15px; 
            font-size: 14px; 
            text-align: center; 
        }
        label { 
            display: block; 
            margin-bottom: 6px; 
            color: #34495e; 
            font-weight: 600; 
            font-size: 14px; 
        }
        input { 
            width: 100%; 
            padding: 10px 12px; 
            margin-bottom: 15px; 
            border: 1px solid #ccc; 
            border-radius: 6px; 
            font-size: 14px; 
        }
        input:focus { 
            border-color: #3498db; 
            outline: none; 
        }
        button { 
            width: 100%; 
            background-color: #3498db; 
            color: white; 
            padding: 10px; 
            border: none; 
            border-radius: 6px; 
            font-size: 16px; 
            font-weight: 600; 
            cursor: pointer; 
            transition: background 0.2s; 
        }
        button:hover { 
            background-color: #2980b9; 
        }
        p { 
            text-align: center; 
            margin-top: 15px; 
            font-size: 14px; 
            color: #666; 
        }
        p a { 
            color: #3498db; 
            text-decoration: none; 
            font-weight: 600; 
        }
        p a:hover { 
            text-decoration: underline; 
        }
    </style>
</head>
<body>
    <div class="login-card">
        <h2>Silakan Login</h2>
        <?php if(isset($error)) echo "<div class='error-msg'>$error</div>"; ?>
        <form method="POST" action="">
            <label>Username</label>
            <input type="text" name="username" placeholder="Masukkan username" required>
            
            <label>Password</label>
            <input type="password" name="password" placeholder="Masukkan password" required>
            
            <button type="submit" name="login">Login</button>
        </form>
        <p>Belum punya akun? <a href="register.php">Daftar di sini</a></p>
    </div>
</body>
</html>