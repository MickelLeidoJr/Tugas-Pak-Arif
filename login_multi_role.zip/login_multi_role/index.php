<?php
session_start();

if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 'admin') {
        header("Location: admin/dashboard.php");
    } elseif ($_SESSION['role'] == 'guru') {
        header("Location: guru/dashboard.php");
    } elseif ($_SESSION['role'] == 'siswa') {
        header("Location: siswa/dashboard.php");
    }
    exit;
} else {
    header("Location: auth/login.php");
    exit;
}
?>